export const LOAD_APP = 'LOAD_APP'
export const ADD_DOT = 'ADD_DOT'
export const LOAD_APP_SUCCESS = 'LOAD_APP_SUCCESS'

export default {
  LOAD_APP,
  ADD_DOT,
  LOAD_APP_SUCCESS
}
