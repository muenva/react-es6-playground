import constants from './counter.constants'

export default {
  increment,
  decrement
}

export function increment () {
  return {
    type: constants.INCREMENT
  }
}
export function decrement () {
  return {
    type: constants.DECREMENT
  }
}
