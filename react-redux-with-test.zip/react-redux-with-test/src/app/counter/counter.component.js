import React from 'react'
import { connect } from 'react-redux'
import { increment, decrement } from './counter.actions'

class Counter extends React.Component {
  _handleIncrement () {
    this.props.dispatch(increment())
  }

  _handleDecrement () {
    this.props.dispatch(decrement())
  }

  render () {
    return (
      <div className='counter'>
        <h3>Counter</h3>
        <h1>{this.props.number}</h1>
        <button onClick={this._handleDecrement.bind(this)}>-</button>
        <button onClick={this._handleIncrement.bind(this)}>+</button>
      </div>
    )
  }
}

Counter.propTypes = {
  number: React.PropTypes.number.isRequired,
  dispatch: React.PropTypes.func.isRequired
}

const mapStateToProps = (state) => {
  const { counter } = state
  return {
    number: counter.number
  }
}

export default connect(mapStateToProps)(Counter)
