export const INCREMENT = 'INCREMENT'
export const DECREMENT = 'DECREMENT'

export default {
  INCREMENT,
  DECREMENT
}
