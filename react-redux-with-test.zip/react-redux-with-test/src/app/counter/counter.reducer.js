import { DECREMENT, INCREMENT } from './counter.constants'

const initialState = {
  number: 0
}

export default function counterReducer (state = initialState, action) {
  switch (action.type) {

    case DECREMENT:
      return Object.assign({}, state, {
        number: --state.number
      })

    case INCREMENT:
      return Object.assign({}, state, {
        number: ++state.number
      })

    default:
      return state
  }
}
