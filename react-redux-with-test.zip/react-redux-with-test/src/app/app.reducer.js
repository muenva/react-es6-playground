import { combineReducers } from 'redux'
import homeReducer from './home/home.reducer'
import counterReducer from './counter/counter.reducer'

export default combineReducers({
  home: homeReducer,
  counter: counterReducer
})
