export default {
  increment,
  decrement
}

export function increment (number) {
  return ++number
}

export function decrement (number) {
  return --number
}
